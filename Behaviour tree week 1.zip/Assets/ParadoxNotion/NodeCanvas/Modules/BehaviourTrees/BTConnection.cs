﻿using NodeCanvas.Framework;


namespace NodeCanvas.BehaviourTrees
{

    ///<summary>The connection object for BehaviourTree nodes</summary>
    public class BTConnection : Connection
    {

    }
}